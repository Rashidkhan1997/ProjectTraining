﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Configuration;
//user define
using SchoolManagementSystem.Entities;
using SchoolManagementSystem.Exceptions;
using SchoolManagementSystem.BL;

namespace SchoolManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AttendanceBL bal = null;
        public MainWindow()
        {
            InitializeComponent();
            bal = new AttendanceBL(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
            PopulateUI();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Attendance a = new Attendance();
                a.AttendanceId = int.Parse(txtAttendanceId.Text);
                a.StudentId = int.Parse(txtStudentId.Text);
                a.Date = (DateTime)dpDate.SelectedDate;
                if (rdAbsent.IsChecked == true)
                {
                    a.Attended = rdAbsent.Content.ToString();
                }
                else
                {
                    a.Attended = rdPresent.Content.ToString();
                }
                bal.Add(a);
                MessageBox.Show("Insert");
                PopulateUI();
            }
            catch (AttendanceException ex1) { MessageBox.Show(ex1.Message); }
            catch (Exception ex2) { MessageBox.Show(ex2.Message); }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }
        public void PopulateUI()
        {

        }


    }
}
