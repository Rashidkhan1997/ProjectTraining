﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
//user define Library
using SchoolManagementSystem.Entities;
using SchoolManagementSystem.Exceptions;
using SchoolManagementSystem.DAL;


namespace SchoolManagementSystem.BL
{
    public class AttendanceBL
    {/// <summary>
/// Author: Rashid M Khan
/// Purpose: Student attendance Exception Layer
/// Date: 10-06-2018               
/// </summary>   
/// 

        AttendanceDAL dal = null;
        public AttendanceBL(string conString)
        {
            dal = new AttendanceDAL(conString);
        }
        //==========================ADD======================================
        public void Add(Attendance attendance)
        {
            try
            {
                if (ValidateAttendance(attendance))
                {
                    dal.Insert(attendance);
                }
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
        }
        //============================DELETE======================================
        public void Delete(int attendanceId)
        {
            try
            {
                
                
                    dal.Delete(attendanceId);
                
            }
            catch(AttendanceException ex1) { throw; }
            catch(Exception ex2) { throw; }
        }

        //===========================UPDATE==========================================
        public void Update(Attendance attendance)
        {
            try
            {
                if ((ValidateAttendance(attendance)))
                {
                    dal.UpdateAttendance(attendance);
                }
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
        }




//============================VALIDATION=========================================

        public bool ValidateAttendance(Attendance attendance)
        {
            StringBuilder sb = new StringBuilder();
            bool validAttendance = true;

            //if (attendance.AttendanceId > 0)
            //{
            //    validAttendance = false;
            //    sb.Append(Environment.NewLine + "Attendance Id Should Not Be Zero");
            //}
            //if (attendance.StudentId  > 0)
            //{
            //    validAttendance = false;
            //    sb.Append(Environment.NewLine + "Student Id Should Not be zero");

            //}
            //if(attendance.Date > DateTime.Now && attendance.Date<DateTime.Now )
            //{
            //    validAttendance = false;
            //    sb.Append(Environment.NewLine + "Date should be Current Date");
            //}

            //if(attendance.Attended.Trim().Length==0)
            //{
            //    validAttendance = false;
            //    sb.Append(Environment.NewLine + "attendance Field Should not be Empty");
            //}
            ////if (!Regex.IsMatch(attendance.AttendanceId, "(^[0-9]+)"))
            ////{
            ////    validAttendance = false;
            ////    sb.Append(Environment.NewLine + "Attendance Id should be only of Number");
            ////}


            return validAttendance;
            
        }


        //=======================SELECT ALL==================================

        public void GetALL(Attendance attendance)
        {
            try
            {
                dal.SelectAll();
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
        }
        //==================SEARCH BY ID======================================
        public void SearchById(int attendanceId)
        {
            try
            {

                dal.Search(attendanceId);
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
        }
    } 


    }

