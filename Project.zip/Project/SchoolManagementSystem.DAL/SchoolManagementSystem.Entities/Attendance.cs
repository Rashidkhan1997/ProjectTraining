﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementSystem.Entities
{
    public class Attendance
    {/// <summary>
/// Author: Rashid M Khan
/// Purpose: Student attendance Entitiy Layer
/// Date: 10-06-2018               
/// </summary>   
//Properties
        public int AttendanceId { get; set; }
        public int StudentId { get; set; }
        public DateTime Date { get; set; }
        public String Attended { get; set; }

        public Attendance()
        {
            this.AttendanceId = 0;
            this.StudentId = 0;
            this.Date = DateTime.Now;
            this.Attended = String.Empty;

        }
    }
}
