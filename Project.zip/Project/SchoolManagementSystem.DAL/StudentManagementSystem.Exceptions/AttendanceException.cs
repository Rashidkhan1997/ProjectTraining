﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SchoolManagementSystem.Entities;

namespace StudentManagementSystem.Exceptions
{
    public class AttendanceException
    {


        public AttendanceException() : base()
        {

        }

        public AttendanceException(string errorMessage) : base(errorMessage)
        {

        }
        public AttendanceException(string message, Exception innerException) : base(message, innerException)
        {

        }

    }
}
