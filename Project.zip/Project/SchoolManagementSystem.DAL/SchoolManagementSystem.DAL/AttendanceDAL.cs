﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.SqlClient;

using SchoolManagementSystem.Exceptions;
using SchoolManagementSystem.Entities;

namespace SchoolManagementSystem.DAL
{/// <summary>
/// Author: Rashid M Khan
/// Purpose: Student attendance DAL Layer
/// Date: 10-06-2018               
/// </summary>                                       
    public class AttendanceDAL
    {
        //For Sql Connection
        SqlConnection cn1 = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public AttendanceDAL(string conString)
        {
            cn1 = new SqlConnection(conString);
        }

        //=======================select All Detail===============================
        public List<Attendance> SelectAll()
        { 
            List<Attendance> attendances = new List<Attendance>();

            try
            {
                //SQL Query For Select All Details of attendance 
                cmd = new SqlCommand("select * from [SMS].[Attendance]", cn1);
                cn1.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Attendance a = new Attendance();
                        a.AttendanceId = Convert.ToInt32(dr[0]);
                        a.StudentId = Convert.ToInt32(dr[1]);                
                        a.Date = Convert.ToDateTime(dr[2]);
                        a.Attended = dr[2].ToString();

                        attendances.Add(a);
                    }
                }
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
            finally
            {
                dr.Close();
                cn1.Close();
            }
            return attendances;
        }

//=================================Insert=====================================
        public void Insert(Attendance attendance)
        {
            try
            {
                //cmd = new SqlCommand("insert into [Rashid].[Teacher] values (@prodName, @price, @expDate)", cn1);
                //With Help OfStore Procedure
                cmd = new SqlCommand("[SMS].[usp_Insert_AttendanceDetails]", cn1);
                cmd.Parameters.AddWithValue("@aAttendance_Id", attendance.AttendanceId);
                cmd.Parameters.AddWithValue("@sStudent_Id", attendance.StudentId);
                cmd.Parameters.AddWithValue("@dDate", attendance.Date);
                cmd.Parameters.AddWithValue("@aAttended", attendance.Attended);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn1.Open();
                cmd.ExecuteNonQuery();
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
            finally { cn1.Close(); }
        }


        //==============Update===========================================
        public void UpdateAttendance(Attendance attendance)
        {
            try
            {


                //Using Stored Procedure
                cmd = new SqlCommand("[SMS].[usp_Update_AttendanceDetails]", cn1);
                cmd.Parameters.AddWithValue("@aAttendance_Id", attendance.AttendanceId);
                cmd.Parameters.AddWithValue("@sStudent_Id", attendance.StudentId);
                cmd.Parameters.AddWithValue("@dDate", attendance.Date);
                cmd.Parameters.AddWithValue("@aAttended", attendance.Attended);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn1.Open();
                cmd.ExecuteNonQuery();
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
            finally { cn1.Close(); }
        }


        //====================Delete by Id==========================================
        public void Delete(int attendanceId)
        {
            try
            {
               
                cmd = new SqlCommand("[SMS].[usp_Delete_AttendanceDetails]", cn1);
                cmd.Parameters.AddWithValue("@id", attendanceId);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn1.Open();
                cmd.ExecuteNonQuery();
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
            finally { cn1.Close(); }
        }

       //===============================Search by Id===================================
        public void Search(int attendanceId)
        {
            try
            {
                cmd = new SqlCommand("[SMS].[usp_FetchById_AttendanceDetails]", cn1);
                cmd.Parameters.AddWithValue("@id", attendanceId);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn1.Open();
                cmd.ExecuteNonQuery();
            }
            catch (AttendanceException ex1) { throw; }
            catch (Exception ex2) { throw; }
            finally { cn1.Close(); }


        }
    }
}
