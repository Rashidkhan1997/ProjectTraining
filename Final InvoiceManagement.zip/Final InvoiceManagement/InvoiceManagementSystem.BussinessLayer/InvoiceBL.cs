﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using InvoiceManagementSystem.BussinessLayer;
using InvoiceManagementSystem.DataAccessLayer;
using InvoiceManagementSystem.Entities;
using InvoiceManagementSystem.Exceptions;
namespace InvoiceManagementSystem.BussinessLayer
{
    public class InvoiceBL
    {
        public static bool ValidateInvoice(Invoice invoice)
        {
            StringBuilder sb = new StringBuilder();
            bool validInvoice = true;
            if (invoice.Id <= 0)
            {
                validInvoice = false;
                sb.Append(Environment.NewLine + "Id should be positive Number.");
            }
            if(invoice.Name.Length<=3)
            {
                validInvoice = false;
                sb.Append(Environment.NewLine + "Name should be greater than 3 ");
            }
            if(invoice.Price<=100 || invoice.Price>=10000)
            {
                validInvoice = false;
                sb.Append(Environment.NewLine + "Price is in Between 100 to 10000");
            }

            if(invoice.InvoiceDate < DateTime.Now.Date)
            {
                validInvoice = false;
                sb.Append(Environment.NewLine + "Invoice Date Should be greater than or equal to today's date");
            }


            if (validInvoice == false)
                throw new InvoiceException(sb.ToString());

            return validInvoice;
        }

        public static bool AddInvoice(Invoice invoice)
        {
            bool invoiceAdded = false;
            try
            {
                if (ValidateInvoice(invoice))
                {
                    invoiceAdded= InvoiceDAL.AddInvoice(invoice);
                }
            }
            catch (InvoiceException)
            {
                throw;
            }
            catch(Exception Ex)
            {
                throw Ex;
            }
            return invoiceAdded;
        }

        public static Invoice SearchInvoice(int invoiceid)
        {
            return InvoiceDAL.SearchInvoice(invoiceid);
        }
        public static List<Invoice> GetAllInvoice()
        {
            return InvoiceDAL.GetAllInvoice();
        }
       

    }
}
