﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvoiceManagementSystem.Entities
{
    [Serializable]
   public class Invoice
    {
        private int id;
        private string name;
        private int price;
        private DateTime invoiceDate;
        public int Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public int Price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }
        public DateTime InvoiceDate
        {
            get
            {
                return invoiceDate;
            }
            set
            {
               invoiceDate = value;
            }
        }
        public Invoice()
        {
          this.id = 0;
            this.name = string.Empty;
           this.price = 0;
            this.invoiceDate = DateTime.Now.Date;
        }
    }
}
