﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using InvoiceManagementSystem.Entities;
namespace InvoiceManagementSystem.Exceptions
{
  public class InvoiceException : ApplicationException
    {
        public InvoiceException() : base()
        {

        }
        public InvoiceException(string message) : base(message)
        {

        }
        public InvoiceException(string message,Exception innerException) : base(message, innerException)
        {

        }
    }
}
