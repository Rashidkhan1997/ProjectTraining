﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

using InvoiceManagementSystem.Entities;
using InvoiceManagementSystem.Exceptions;

namespace InvoiceManagementSystem.DataAccessLayer
{
    public class InvoiceDAL
    {
        public static List<Invoice> invoices = new List<Invoice>();

        public static bool AddInvoice(Invoice invoice)
        {
            try
            {
                invoices.Clear();
                // get invoices from file and store
                invoices = GetFromFile();
                //add  the new invoices
                invoices.Add(invoice);
                //Serialize
                Stream s = File.Open("Invoice.txt", FileMode.Create, FileAccess.ReadWrite);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, invoices);
                s.Close();
                
                return true;
            }
            catch (Exception Ex)
            {
                return false;
            }
        }

        public static Invoice SearchInvoice(int invoiceid)
        {
            //By Linq
            //var invoice = GetFromFile();
            //var result = from p in invoice
            //             where p.Id == invoiceid
            //             select p;



            //if (result.Count() == 0)
            //    return new Invoice();
            //else
            //    return result.FirstOrDefault() ;

            //lambda Expression
            var invoicesObj = GetFromFile();
            var result = invoicesObj.Where(p => p.Id == invoiceid).ToList();
            if (result.Count() == 0)
            {
                return new Invoice();
            }
            else
                return result.FirstOrDefault();


        }
        public static List<Invoice> GetAllInvoice()
        {
            var invoice = GetFromFile();
            return invoice;
        }

        public static List<Invoice> GetFromFile()
        {
            // De-Serialize
            List<Invoice> invoicesObj = new List<Invoice>();
            Stream s = File.Open("Invoice.txt", FileMode.OpenOrCreate, FileAccess.Read);
            BinaryFormatter b = new BinaryFormatter();
            if (s.Length != 0)
                invoicesObj = (List<Invoice>)b.Deserialize(s);

                s.Close();
            
            return invoicesObj;

        }
        
      
    }
}

