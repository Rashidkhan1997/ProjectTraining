﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using InvoiceManagementSystem.Entities;
using InvoiceManagementSystem.Exceptions;
using InvoiceManagementSystem.BussinessLayer;
namespace InvoiceManagementSystem.PresentationLayer
{
    public class Program
    {
        static void Main(string[] args)
        {
            int ch;
            do
            {

                DisplayMenu();
                Console.WriteLine("Enter Your Choice");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        AddInvoice();
                        break;
                    case 2:
                        SearchInvoice();
                        break;
                    case 3:
                        ViewAllInvoices();
                        break;
                    default:
                        break;

                }
            } while (ch != 4);
        }
        public static void AddInvoice()
        {
            try {
                Invoice invoice = new Invoice();
                Console.WriteLine("Enter Id");
                invoice.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Name");
                invoice.Name = Console.ReadLine();
                Console.WriteLine("Enter Price");
                invoice.Price = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Invoice date (MM/DD/YYYY) Format");
                invoice.InvoiceDate = DateTime.Parse(Console.ReadLine());
                if (InvoiceBL.AddInvoice(invoice))
                    Console.WriteLine("Invoice Added Successfully");
                else
                    Console.WriteLine("Unable to add Invoice");
            }
            catch(InvoiceException Ex)
            {
                Console.WriteLine(Ex.Message);
            }
            }
        public static void SearchInvoice()
        {
            int id;
            Console.WriteLine("Enter Id:");
            id = int.Parse(Console.ReadLine());
            var result = InvoiceBL.SearchInvoice(id);
            if (result.Id == 0)
            {
                Console.WriteLine("NO DATA FOUND");
            }
            else
                Console.WriteLine($"Id : {result.Id}, Name: {result.Name}, Price :{result.Price}, Date:{result.InvoiceDate}");
        }
        public static void DisplayMenu()
        {
            Console.WriteLine("***********************************");
            Console.WriteLine("Invoice Management System");
            Console.WriteLine("***********************************");
            Console.WriteLine("1.  Add Invoice");
            Console.WriteLine("2.  Search Invoice");
            Console.WriteLine("3.  View All Invoice");
            Console.WriteLine("4.  Exit");

        }
        public static void ViewAllInvoices()
        {
            var result = InvoiceBL.GetAllInvoice();
            foreach (var r in result)
            {
                Console.WriteLine($" ID {r.Id} , Name : {r.Name} , Salary: {r.Price}, Date: {r.InvoiceDate}");
            }
        }

    }
}

